The two project in this directory are what discussed in chapter 4:
The json-processing is a standalone maven module which shows how to perform different json manipulations. 
The nio-servlet is a NetBeans project showing how to use the NIO servlets.