The two project in this directory are what discussed in chapter 2:
The basic-polling is a NetBeans project showing how basic polling works.
The FTSServlet is a NetBeans project showing how SSO and WebSockets work.