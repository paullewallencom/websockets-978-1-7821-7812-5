This is a very basic sample which shows JAXB and JAXRS resources and use of MessageBody readers and writers.

To run
 http://localhost:8080/provider-sample/TestServlet