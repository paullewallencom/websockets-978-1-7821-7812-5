Deploy the war and
Go to http://localhost:8080/libraryApp/index.html