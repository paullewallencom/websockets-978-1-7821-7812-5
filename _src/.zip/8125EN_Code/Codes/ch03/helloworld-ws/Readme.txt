Deploy helloworld-ws.war to GlassFish 4.0

Go to http://localhost:8080/helloworld-ws/ in browser
To View WebSockets headers you can
Open Chrome -> view-> Developer Tools
Click on Network
Select book in element and click on frames