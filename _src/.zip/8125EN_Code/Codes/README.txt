The code for the different chapters can be found in the respective folders.
To run the samples you will need
GlassFish 4.0
Maven 3.0.x
Some samples in Chapter 2 and 4 are Netbeans projects so you can run them with 
Netbeans 7.4